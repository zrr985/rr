CH：
QTCreator demo使用方法:
1, 下载qtcreator软件，直接通过qtcreator打开项目文件即可运行
2，如果没有安装qtcreator软件，要确保系统中安装的有qmake，可以利用qmake生成makefile文件，进行编译运行，步骤如下：
（1）在demo的文件目录下，使用qmake -makefile命令生成makefile文件
（2）生成makefile之后，使用make命令进行项目可执行文件的生成，以BasicDemo为例，生成完可执行文件后，通过./BasicDemo即可运行程序

EN：
How to use QTCreator demo:
1, download qtcreator software, open the project file directly through qtcreator to run
2, If you don't have qtcreator software installed, make sure there is qmake installed in your system, you can use qmake to generate makefile file to compile and run, steps are as follows.
(1) In the demo file directory, use the qmake -makefile command to generate the makefile file
(2) After generating the makefile, use the make command to generate the project executable file, take BasicDemo as an example, after generating the executable file,
 you can run it by . /BasicDemo to run the program
