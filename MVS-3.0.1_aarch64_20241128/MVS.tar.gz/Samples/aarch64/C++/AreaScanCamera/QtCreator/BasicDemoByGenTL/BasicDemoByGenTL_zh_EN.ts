<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en" sourcelanguage="zh_CN">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="27"/>
        <source>枚举Interface</source>
        <translation type="unfinished">Enum Interface</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="40"/>
        <source>枚举设备</source>
        <translation type="unfinished">Enum Device</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="53"/>
        <source>打开设备</source>
        <translation type="unfinished">Open
Device</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="66"/>
        <source>关闭设备</source>
        <translation type="unfinished">Close
Device</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="79"/>
        <source>连续模式</source>
        <translation type="unfinished">Continuous</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="92"/>
        <source>触发模式</source>
        <translation type="unfinished">Triggle Mode</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="105"/>
        <source>开始采集</source>
        <translation type="unfinished">Start</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="118"/>
        <source>停止采集</source>
        <translation type="unfinished">Stop</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="131"/>
        <source>软触发</source>
        <translation type="unfinished">Trigger By
SoftWare</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="144"/>
        <source>软触发一次</source>
        <translation type="unfinished">Trigger Once</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="177"/>
        <source>Interface:</source>
        <translation type="unfinished">Interface:</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="190"/>
        <source>Device:</source>
        <translation type="unfinished">Device:</translation>
    </message>
</context>
</TS>
