<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en" sourcelanguage="zh_CN">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>BasicDemo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="27"/>
        <source>查找设备</source>
        <translation type="unfinished">Search Device</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="50"/>
        <source>打开设备</source>
        <translation type="unfinished">Open
Device</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="66"/>
        <source>关闭设备</source>
        <translation type="unfinished">Close
Device</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="82"/>
        <source>开始采集</source>
        <translation type="unfinished">Start</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="98"/>
        <source>停止采集</source>
        <translation type="unfinished">Stop</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="114"/>
        <source>连续模式</source>
        <translation type="unfinished">Continuous</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="130"/>
        <source>触发模式</source>
        <translation type="unfinished">Trigger Mode</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="146"/>
        <source>软触发一次</source>
        <translation type="unfinished">Trigger
Once</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="162"/>
        <source>软触发</source>
        <translation type="unfinished">Trigger By
SoftWare</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="175"/>
        <source>曝光</source>
        <translation type="unfinished">Exposure Time</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="201"/>
        <source>增益</source>
        <translation type="unfinished">Gain</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="227"/>
        <source>帧率</source>
        <translation type="unfinished">Frame Rate</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="256"/>
        <source>获取参数</source>
        <translation type="unfinished">Get
Parameter</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="272"/>
        <source>设置参数</source>
        <translation type="unfinished">Set
Parameter</translation>
    </message>
</context>
</TS>
